# (Preview) Welcome to AI Toolkit for VS Code

Get [AI Toolkit for VS Code](https://aka.ms/WindowsAI-Studio) to add AI features to your app.

## Dataset

## Evaluation
